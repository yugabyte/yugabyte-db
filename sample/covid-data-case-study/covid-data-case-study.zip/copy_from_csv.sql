 \copy mask_wearers from 'csv-files/covidcast-fb-survey-smoothed_wearing_mask-2020-09-13-to-2020-11-01.csv' with (format 'csv', header true);

