\i ingest-the-data.sql
\i analysis-queries.sql
\i synthetic-data.sql
