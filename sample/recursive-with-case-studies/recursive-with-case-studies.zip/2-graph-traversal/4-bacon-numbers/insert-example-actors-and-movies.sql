do $body$
begin
  -- Movies: 28 in all

  insert into movies(movie) values

   ('All''s Well That Ends Well'),
   ('Antony and Cleopatra'),
   ('As You Like It'),
   ('Comedy of Errors'),
   ('Coriolanus'),
   ('Cymbeline'),
   ('Hamlet'),
   ('Julius Caesar'),
   ('King John'),
   ('King Lear'),
   ('Love''s Labour''s Lost'),
   ('Macbeth'),
   ('Measure for Measure'),
   ('Merchant of Venice'),
   ('Merry Wives of Windsor'),
   ('Midsummer Night''s Dream'),
   ('Much Ado about Nothing'),
   ('Othello'),
   ('Pericles'),
   ('Romeo and Juliet'),
   ('Taming of the Shrew'),
   ('The Tempest'),
   ('Timon of Athens'),
   ('Titus Andronicus'),
   ('Troilus and Cressida'),
   ('Twelfth Night'),
   ('Two Gentlemen of Verona'),
   ('Winter''s Tale')

  on conflict do nothing;

  ------------------------------------------------------------
  -- Actors: 50 in all

  insert into actors(actor) values

   ('Alfie'),
   ('Alice'),
   ('Andy'),
   ('Bill'),
   ('Charlie'),
   ('Chloe'),
   ('Chris'),
   ('Claire'),
   ('Daniel'),
   ('Dave'),
   ('Dick'),
   ('Doris'),
   ('Ellie'),
   ('Emily'),
   ('Emma'),
   ('Eva'),
   ('Fred'),
   ('Grace'),
   ('Hazel'),
   ('Helen'),
   ('Henry'),
   ('James'),
   ('Joan'),
   ('John'),
   ('Josh'),
   ('Julian'),
   ('Ken'),
   ('Kevin'),
   ('Layla'),
   ('Leo'),
   ('Liam'),
   ('Lily'),
   ('Luke'),
   ('Mary'),
   ('Nathan'),
   ('Noah'),
   ('Nora'),
   ('Owen'),
   ('Penny'),
   ('Ryan'),
   ('Sally'),
   ('Sara'),
   ('Sophie'),
   ('Stella'),
   ('Steve'),
   ('Susan'),
   ('Theo'),
   ('Tom'),
   ('Vicky'),
   ('Zoe')

  on conflict do nothing;
end;
$body$;
