\i ../1-infrastructure/0-install-all-with-raw-paths-tracing.sql
\i install-remaining-common-code.sql
\i insert-synthetic-data.sql
\o results/synthetic-data.txt
\i do-insert-edges.sql
\i find-synthetic-data-paths.sql
\o
