\o 7-stress-test-results/pure-with.txt
\t on

select '"pure WITH" - Number of nodes: '||:nr_nodes;

\ir ../../2-find-paths-implementations/cr-find-paths-with-nocycle-check.sql
call start_stopwatch();
call find_paths(seed => 'n001');
select 'elapsed time (pure WITH): '||stopwatch_reading() as t;

select 'count(*) from raw_paths: '||ltrim(to_char(count(*), '9,999,999')) from raw_paths;

\t off
\o
