-- Get a clean slate for the "paths" tables before each timing test
-- by dropping and re-creating them all.
----------------------------------------------------------------------

\set method '\''pure-with'\''
\ir ../../1-infrastructure/cr-raw-paths-no-tracing.sql
\ir ../../1-infrastructure/cr-supporting-path-tables.sql
\ir do-stress-test-kernel.sql

\set method '\''prune-false'\''
\ir ../../1-infrastructure/cr-raw-paths-no-tracing.sql
\ir ../../1-infrastructure/cr-supporting-path-tables.sql
\ir do-stress-test-kernel.sql

\set method '\''prune-true'\''
\ir ../../1-infrastructure/cr-raw-paths-no-tracing.sql
\ir ../../1-infrastructure/cr-supporting-path-tables.sql
\ir do-stress-test-kernel.sql
