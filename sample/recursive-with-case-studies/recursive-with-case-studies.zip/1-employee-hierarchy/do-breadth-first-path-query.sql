select cardinality(path) as depth, path
from top_down_path
order by
  depth,
  path[cardinality(path)];
