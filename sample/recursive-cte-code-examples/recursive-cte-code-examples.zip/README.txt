There are FIVE master scripts corresponding to the noted different subsections of the doc.
The location of each is speified w.r.t. the directory where you unzip "recursive-with-case-studies.zip".
Each produces reports on its "results" subdirectory. The reports shipped in the zip all end with "-0.txt".
Use your favorite "diff" app to compare what your tests generate with these.
Of course, when the results include timings, these are bound to differ a bit.

1. Case study�using a WITH clause recursive substatement to traverse a hierarchy
    https://docs.yugabyte.com/latest/api/ysql/the-sql-language/with-clause/emps-hierarchy/

  Here is the master script:
    1-employee-hierarchy/0.sql >> results

2. Using a WITH clause recursive substatement to traverse graphs of all kinds
    https://docs.yugabyte.com/latest/api/ysql/the-sql-language/with-clause/traversing-general-graphs/

  Here are the master scripts:
    2-graph-traversal/3-use-case-agnostic-graphs-of-all-kinds/0.sql >> 6-results
    2-graph-traversal/3-use-case-agnostic-graphs-of-all-kinds/do-stress-test.sql >> 7-stress-test-results

3. Computing Bacon Numbers for a small set of synthetic actors and movies data
    https://docs.yugabyte.com/latest/api/ysql/the-sql-language/with-clause/bacon-numbers/synthetic-data/

  Here are the master scripts:
    2-graph-traversal/4-bacon-numbers/1-process-synthetic-data.sql >> results
    2-graph-traversal/4-bacon-numbers/2-process-imdb-data.sql >> results
