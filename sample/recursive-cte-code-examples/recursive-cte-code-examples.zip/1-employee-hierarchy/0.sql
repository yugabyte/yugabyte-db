\o results/results.txt
set client_min_messages = warning;

\i cr-table.sql
\i do-assert-is-hierarchy.sql
\i cr-view-top-down-simple.sql
\i do-breadth-first-query.sql
\i cr-view-top-down-paths.sql
\i do-breadth-first-path-query.sql
\i do-assert-top-down-path-view-and-top-down-simple-view-same-info.sql
\i do-depth-first-query.sql
\i do-indented-depth-first-query.sql
\i do-unix-tree-query.sql
\i cr-function-unix-tree.sql
\i do-bottom-up-simple-query.sql
\i cr-function-bottom-up-path.sql
\i cr-function-bottom-up-path-display.sql

\o
