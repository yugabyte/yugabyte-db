select
  depth,
  mgr_name,
  name
from top_down_simple
order by
  depth,
  mgr_name nulls first,
  name;
