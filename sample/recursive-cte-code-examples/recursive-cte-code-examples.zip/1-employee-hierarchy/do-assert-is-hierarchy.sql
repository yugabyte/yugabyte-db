do $body$
begin
  assert (select count(*) from emps where mgr_name is null) = 1,
    'Rule "Employee graph is a hierarchy" does not hold';
end;
$body$;
