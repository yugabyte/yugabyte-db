select cardinality(path) as depth, path
from top_down_paths
order by
  depth,
  path[cardinality(path)];
