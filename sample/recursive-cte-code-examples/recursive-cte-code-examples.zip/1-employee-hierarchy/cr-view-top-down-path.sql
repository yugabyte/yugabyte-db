create or replace view top_down_path(path) as
with
  recursive hierarchy_of_emps(path, name) as (
    (
      select array['n/a'], name
      from emps
      where mgr_name is null
    )

    union all

    (
      select h.path||e.mgr_name, e.name
      from emps as e
      inner join hierarchy_of_emps as h on e.mgr_name = h.name 
    )
  )
select path[2:cardinality(path)]||name as path
from hierarchy_of_emps;
