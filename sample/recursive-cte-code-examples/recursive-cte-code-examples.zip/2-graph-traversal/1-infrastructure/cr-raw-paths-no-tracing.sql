call create_path_table('raw_paths', false);
drop function if exists raw_paths_trg_f() cascade;
