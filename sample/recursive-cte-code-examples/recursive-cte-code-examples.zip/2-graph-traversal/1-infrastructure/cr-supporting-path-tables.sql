call create_path_table('shortest_paths',        false);
call create_path_table('unq_containing_paths',  false);
call create_path_table('temp_paths',            true);
call create_path_table('previous_paths',        true);

create unique index shortest_paths_start_terminal_unq on shortest_paths(start(path), terminal(path));
