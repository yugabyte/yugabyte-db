-- Because this stopwatch code is generaically useful, you might want to
-- install it centrally and it make available to all users by including the
-- schema where it lives in the search path. Without this
--
--   set search_path = "$user"
--
-- before the main script, and this
--
--   set search_path = "$user", 'admin'
--
-- at the end, you'd experience name collision problems.

set search_path = "$user";
--------------------------------------------------------------------------------

drop procedure if exists start_stopwatch() cascade;
drop function if exists stopwatch_reading() cascade;

create procedure start_stopwatch()
language plpgsql
as $body$
declare
  -- Make a memo of the current wall-clock time.
  start_time constant text not null := clock_timestamp()::text;
begin
  execute 'set stopwatch.start_time to '''||start_time||'''';
end;
$body$;

create function stopwatch_reading()
  returns text
  -- It's critical to use "volatile". Else wrong results.
  volatile
language plpgsql
as $body$
declare
  -- Read the starting wall-clock time from the memo.
  start_time constant timestamptz not null := current_setting('stopwatch.start_time');

  -- Read the current wall-clock time.
  curr_time constant timestamptz not null := clock_timestamp();
  diff constant interval not null := curr_time - start_time;

  hours    constant numeric := extract(hours   from diff);
  minutes  constant numeric := extract(minutes from diff);
  seconds  constant numeric := extract(seconds from diff);
begin
  return
    case
      when seconds < 0.020
        and minutes < 1
        and hours < 1                               then 'less than ~20 ms.'

      when seconds between 0.020 and 2.0
        and minutes < 1
        and hours < 1                               then ltrim(to_char(round(seconds*1000), '999999'))||' ms.'

      when seconds between 2.0 and  59.999
        and minutes < 1
        and hours < 1                               then ltrim(to_char(seconds, '99.9'))||' sec.'

      when minutes between 1 and 59
        and hours < 1                               then ltrim(to_char(minutes, '99'))||':'||
                                                         ltrim(to_char(seconds, '09'))||' min.'

      else                                               ltrim(to_char(hours,   '09'))||':'||
                                                         ltrim(to_char(minutes, '09'))||':'||
                                                         ltrim(to_char(seconds, '09'))||' hours'
    end;
end;
$body$;

--------------------------------------------------------------------------------
set search_path = "$user", 'admin';
