call start_stopwatch();
select pg_sleep(17.5);
select 'reading after pg_sleep(17.5): '||stopwatch_reading();
