\c demo u1
set session time zone 'US/Eastern';
show timezone;

call start_stopwatch();
select pg_sleep(1.234);
set session time zone 'US/Pacific';
select stopwatch_reading();

show timezone;
