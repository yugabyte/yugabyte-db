\i ../2-find-paths-implementations/cr-find-paths-with-nocycle-check.sql
\i ../2-find-paths-implementations/cr-find-paths-with-pruning.sql

\i cr-decorated-paths-report.sql
\i cr-actors-movies-cast-members-tables.sql
\i cr-actors-movies-edges-table-and-proc.sql
