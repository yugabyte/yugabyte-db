/*

select actor, movie
from cast_members
order by actor, movie;

select movies, node_1, node_2 from edges
where node_1 < node_2
order by 1, 2, 3
limit 50;

*/;
