call find_paths('Kevin Bacon (I)', true);

\t on
select 'total number of pruned paths: '||count(*)::text from raw_paths;

select t from list_paths('raw_paths');

call restrict_to_unq_containing_paths('raw_paths', 'unq_containing_paths');
select 'total number of unique containing paths: '||count(*)::text from unq_containing_paths;

select 'Decorated shortest path to Christopher Nolan';
select t from decorated_paths_report('raw_paths', 'Christopher Nolan');
\t off
