\i ../1-infrastructure/1-install-all-no-raw-paths-tracing.sql
\i install-remaining-common-code.sql
\o results/imdb-data.txt
\i insert-imdb-data.sql
\i do-insert-edges.sql
\i find-imdb-data-paths.sql
\o
