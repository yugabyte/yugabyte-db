 \o 7-stress-test-results/10-nodes--prune-true.txt

