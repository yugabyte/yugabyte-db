drop function if exists start_spooling_script(int, text) cascade;

create function start_spooling_script(nr_nodes in int, method in text)
  returns text
  language plpgsql
as $body$
begin
  return '\o 7-stress-test-results/'||ltrim(nr_nodes::text)||'-nodes--'||method||'.txt';
end;
$body$;
