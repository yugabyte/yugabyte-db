drop procedure if exists invoke_find_paths(text) cascade;

create procedure invoke_find_paths(method in text)
  language plpgsql
as $body$
begin
  case method
    when 'pure-with'   then call find_paths(seed => 'n001');
    when 'prune-false' then call find_paths(seed => 'n001', prune => false);
    when 'prune-true'  then call find_paths(seed => 'n001', prune => true);
  end case;
end;
$body$;
