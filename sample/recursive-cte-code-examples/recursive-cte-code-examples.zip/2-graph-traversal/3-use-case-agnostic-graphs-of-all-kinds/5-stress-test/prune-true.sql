\o 7-stress-test-results/prune-true.txt
\t on

select '"prune TRUE" - Number of nodes: '||:nr_nodes;

\ir ../../2-find-paths-implementations/cr-find-paths-with-pruning.sql
call start_stopwatch();
call find_paths(start_node => 'n001', prune => true);
select 'elapsed time (prune => TRUE): '||stopwatch_reading() as t;

select 'count(*) from raw_paths: '||ltrim(to_char(count(*), '9,999,999')) from raw_paths;

select t from list_paths('raw_paths');

\t off
\o
