\i ../1-infrastructure/0-install-all-with-raw-paths-tracing.sql
\i cr-edges-table.sql

\i 1-undirected-cyclic-graph/denormalized-edges-table-approach.sql
\i 1-undirected-cyclic-graph/normalized-edges-table-approach.sql
\i 1-undirected-cyclic-graph/pruned-paths-approach.sql
\i 1-undirected-cyclic-graph/assert-post-factum-filtered-same-as-pruned.sql

\i 1-undirected-cyclic-graph/demo-unq-containing-paths.sql

\i 2-directed-cyclic-graph/do-it.sql

\i 3-directed-acyclic-graph/do-it.sql

\i 4-rooted-tree/do-it.sql
