-- This test takes about 15 minutes to complete using a single-node
-- YugabyteDB cluster on a on a high-end Mac Book

\i ../1-infrastructure/1-install-all-no-raw-paths-tracing.sql
\i cr-edges-table.sql
alter table edges drop constraint if exists edges_chk cascade;
alter table edges add constraint edges_chk check(node_1 <> node_2);

\i 5-stress-test/cr-populate-maximum-connectvity-edges.sql
\i 5-stress-test/cr-start-spooling-script.sql
\ir ../2-find-paths-implementations/cr-find-paths-with-nocycle-check.sql
\ir ../2-find-paths-implementations/cr-find-paths-with-pruning.sql
\i 5-stress-test/cr-invoke-find-paths.sql

\set nr_nodes 4
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 5
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 6
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 7
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 8
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 9
\i 5-stress-test/do-stress-test-for-all-methods.sql

\set nr_nodes 10
\i 5-stress-test/do-stress-test-for-all-methods.sql
