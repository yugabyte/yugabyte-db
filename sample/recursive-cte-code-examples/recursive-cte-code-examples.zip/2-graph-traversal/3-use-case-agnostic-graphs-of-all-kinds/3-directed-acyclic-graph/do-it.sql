\ir ../../2-find-paths-implementations/cr-find-paths-no-nocycle-check.sql

delete from edges;
alter table edges drop constraint if exists edges_chk cascade;
alter table edges add constraint edges_chk check(node_1 <> node_2);

insert into edges(node_1, node_2) values
  ('n1', 'n2'),
  ('n1', 'n3'),
  ('n2', 'n5'),
  ('n2', 'n6'),
  ('n3', 'n6'),
  ('n4', 'n3'),
  ('n4', 'n7'),
  ('n3', 'n7');

call find_paths(seed => 'n1');
call restrict_to_shortest_paths('raw_paths', 'shortest_paths');

\o 6-results/3-directed-acyclic-graph.txt
\t on
select t from list_paths('raw_paths');
select t from list_paths('shortest_paths');
\t off

do $body$
declare
  node text not null := '';
begin
  for node in (
    select distinct node_1 from edges
    where node_1 <> 'n1')
  loop
    call find_paths(seed => node);
    call restrict_to_shortest_paths('raw_paths', 'shortest_paths', append=>true);
  end loop;
end;
$body$;

\t on
select t from list_paths('shortest_paths');
\t off
\o
