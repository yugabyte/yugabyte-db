\o results/pg.txt
\ir 0.sql
\o
