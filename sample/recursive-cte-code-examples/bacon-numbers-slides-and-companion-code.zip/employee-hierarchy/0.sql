set client_min_messages = warning;

\ir 1-cr-table.sql
\ir 2-bare-recursive-cte.sql
\ir 3-top-down-paths.sql
\ir 4-bottom-up-path.sql
