\o results/yb.txt
\ir 0.sql
\o
