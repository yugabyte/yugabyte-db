\o results/pg.txt
\ir 00.sql
\o
