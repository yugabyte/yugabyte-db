\o results/yb.txt
\ir 00.sql
\o
