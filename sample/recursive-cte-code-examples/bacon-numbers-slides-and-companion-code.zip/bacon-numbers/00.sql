set client_min_messages = warning;

-------------------------------------------------------
-- Synthetic Data
-------------------------------------------------------
\ir 01-cr-tables.sql
\ir 02-cr-edges-table-and-proc.sql
\ir 03-insert-synthetic-data.sql

\ir 04-populate-edges-table-and-check-contents.sql

\ir 05-cr-raw-paths-table.sql
\ir 06-cr-list-paths.sql
\ir 07-find-paths-naive.sql

\ir 08-cr-raw-paths-with-tracing.sql
\ir 09-find-paths-no-pruning.sql

\ir 10-cr-restrict-to-unq_containing-paths.sql

\ir 11-find-paths-with-pruning.sql

\ir 12-cr-decorated-paths-report.sql

\ir 99-pruning-demo.sql

-------------------------------------------------------
-- Real IMDB data
-------------------------------------------------------
\ir 13-insert-imdb-data.sql
\ir 14-inspect-imdb-data.sql
\ir 15-find-imdb-paths.sql
