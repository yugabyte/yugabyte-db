\ir cr-duration-as-text.sql
\ir test-duration-as-text.sql

\ir cr-stopwatch.sql
\ir test-stopwatch.sql

\ir cr-cross-session-stopwatch.sql
\ir test-cross-session-stopwatch.sql
