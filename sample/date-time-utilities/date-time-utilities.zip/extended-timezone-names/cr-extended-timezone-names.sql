drop view if exists extended_timezone_names cascade;
create view extended_timezone_names as
select
  name,
  p.abbrev,
  t.std_abbrev,
  t.dst_abbrev,
  p.utc_offset,
  t.std_offset,
  t.dst_offset,
  p.is_dst,
  t.country_code,
  t.lat_long,
  t.region_coverage,
  t.status
from
  pg_timezone_names as p
  inner join
  tz_database_time_zones_extended as t using (name);
