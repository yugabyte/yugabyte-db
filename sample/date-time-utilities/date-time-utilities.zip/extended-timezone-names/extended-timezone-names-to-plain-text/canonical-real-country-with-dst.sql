-- There's no \or (relative spool) metacommand.
-- So when this file is invoked by "0.sql" on its parent directory,
-- the spool file path must be given relative to that parent parent directory.

\o extended-timezone-names/extended-timezone-names-to-plain-text/spool/canonical-real-country-with-dst.txt
select
  name,
  std_abbrev,
  dst_abbrev,
  to_char_interval(std_offset) as "STD offset",
  to_char_interval(dst_offset) as "DST offset",
  country_code,
  region_coverage
from canonical_real_country_with_dst
order by std_offset, name;
\o
