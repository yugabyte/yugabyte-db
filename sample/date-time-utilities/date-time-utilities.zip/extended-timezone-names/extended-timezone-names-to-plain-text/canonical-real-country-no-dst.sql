-- There's no \or (relative spool) metacommand.
-- So when this file is invoked by "0.sql" on its parent directory,
-- the spool file path must be given relative to that parent parent directory.

\o extended-timezone-names/extended-timezone-names-to-plain-text/spool/canonical-real-country-no-dst.txt
select
  name,
  abbrev,
  to_char_interval(utc_offset) as "UTC offset",
  country_code,
  region_coverage
from canonical_real_country_no_dst
order by utc_offset, name;
\o
