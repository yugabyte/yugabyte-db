call start_stopwatch();
\ir interval-utilities/0.sql
\ir internal-interval-representation-model/0.sql
\ir interval-domains/0.sql
\ir extended-timezone-names/0.sql
\ir set-timezone-and-at-timezone-encapsulations/0.sql
\ir ways-to-spec-utc-offset/legal-scopes-for-syntax-context.sql

\o 0.txt
\t on
select 'Installation took '||stopwatch_reading_as_text();
\t off
\o
