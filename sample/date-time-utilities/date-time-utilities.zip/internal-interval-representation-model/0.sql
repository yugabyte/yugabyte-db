\ir cr-interval-mm-dd-ss.sql
\ir cr-assert-model-ok.sql
\ir cr-test-internal-interval-representation-model.sql
