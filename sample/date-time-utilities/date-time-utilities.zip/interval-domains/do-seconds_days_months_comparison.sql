drop function if exists seconds_days_months_comparison(double precision) cascade;

create function seconds_days_months_comparison(secs in double precision)
  returns table(x text)
  language plpgsql
as $body$
declare
  msg                            text             not null := '';
  hint                           text             not null := '';
  seconds_per_day       constant double precision not null := 24*60*60;
  avg_days_per_year     constant double precision not null := 365.2425;
  avg_seconds_per_year  constant double precision not null := seconds_per_day*avg_days_per_year;
  months_per_year       constant double precision not null := 12;
begin
  set timezone = 'UTC';
  declare
    i_secs  constant interval_seconds_t not null := interval_seconds(secs=>secs);
    t0      constant timestamptz        not null := '4713-01-01 00:00:00 UTC BC';
    t1      constant timestamptz        not null := t0 + i_secs;
  begin
    declare
      i_days       constant interval_days_t   not null := interval_days  (t1, t0);
      i_months     constant interval_months_t not null := interval_months(t1, t0);

      ss           constant double precision  not null := (interval_mm_dd_ss(i_secs  )).ss;
      dd           constant int               not null := (interval_mm_dd_ss(i_days  )).dd;
      mm           constant int               not null := (interval_mm_dd_ss(i_months)).mm;

      yrs_from_ss  constant numeric           not null := round((ss/avg_seconds_per_year)::numeric, 3);
      yrs_from_dd  constant numeric           not null := round((dd/avg_days_per_year   )::numeric, 3);
      yrs_from_mm  constant numeric           not null := round((mm/months_per_year     )::numeric, 3);
    begin
      x := 't0:          '||lpad(to_char(t0, 'yyyy-mm-dd hh24:mi:ss BC'), 25);  return next;
      x := 't1:          '||lpad(to_char(t1, 'yyyy-mm-dd hh24:mi:ss BC'), 25);  return next;
      x := '';                                                                  return next;
      x := 'i_secs:      '||i_secs::text;                                       return next;
      x := 'i_days:      '||i_days::text;                                       return next;
      x := 'i_months:    '||i_months::text;                                     return next;
      x := '';                                                                  return next;
      x := 'yrs_from_ss  '||yrs_from_ss;                                        return next;
      x := 'yrs_from_dd: '||yrs_from_dd;                                        return next;
      x := 'yrs_from_mm: '||yrs_from_mm;                                        return next;
    end;
  end;
exception when interval_field_overflow then
  get stacked diagnostics
    msg = message_text,
    hint = pg_exception_hint;
  raise info '%', msg;
  raise info '%', hint;
end;
$body$;

select x from seconds_days_months_comparison(7730941132799);
select x from seconds_days_months_comparison( 200000000000);
select x from seconds_days_months_comparison(      8854000);
                                                     
-- select x from seconds_days_months_comparison(7730941132800);
