-- CREATE THE DOMAINS

drop domain if exists interval_months_t cascade;
drop function if exists interval_months_ok(interval) cascade;

create function interval_months_ok(i in interval)
  returns boolean
  language plpgsql
as $body$
begin
  if i is null then
    return true;
  else
    declare
      mm_dd_ss  constant interval_mm_dd_ss_t not null := interval_mm_dd_ss(i);
    begin
      return mm_dd_ss.dd = 0 and mm_dd_ss.ss = 0;
    end;
  end if;
end;
$body$;

create domain interval_months_t as interval check(interval_months_ok(value));

----------------------------------------

drop domain if exists interval_days_t cascade;
drop function if exists interval_days_ok(interval) cascade;

create function interval_days_ok(i in interval)
  returns boolean
  language plpgsql
as $body$
begin
  if i is null then
    return true;
  else
    declare
      mm_dd_ss constant interval_mm_dd_ss_t not null := interval_mm_dd_ss(i);
    begin
      return mm_dd_ss.mm = 0 and mm_dd_ss.ss = 0;
    end;
  end if;
end;
$body$;

create domain interval_days_t as interval check(interval_days_ok(value));

----------------------------------------

drop domain if exists interval_seconds_t cascade;
drop function if exists interval_seconds_ok(interval) cascade;

create function interval_seconds_ok(i in interval)
  returns boolean
  language plpgsql
as $body$
begin
  if i is null then
    return true;
  else
    declare
      mm_dd_ss constant interval_mm_dd_ss_t not null := interval_mm_dd_ss(i);
    begin
      return mm_dd_ss.mm = 0 and mm_dd_ss.dd = 0;
    end;
  end if;
end;
$body$;

create domain interval_seconds_t as interval check(interval_seconds_ok(value));

--==============================================================================
-- IMPLEMENT THE FUNCTIONALITY

-- interval_months

drop procedure if exists assert_interval_months_in_range(bigint);

create procedure assert_interval_months_in_range(months in bigint)
  language plpgsql
as $body$
declare
  -- Determined by empirical testing.
  -- causes error "22008: timestamp out of range".
  -- select '4713-01-01 00:00:00 UTC BC'::timestamptz + make_interval(months=>3587868);
  max_months constant bigint not null :=  3587867;

  -- "22015" is pre-defined and mapped to "interval_field_overflow".
  code     constant text   not null := '22015';
  hint     constant text   not null := 'Max interval_months_t exceeded';
begin
  if abs(months) > max_months then
    declare
      msg constant text := months::text||' abs(months) exceeded limit of '||max_months::text;
    begin
      raise exception using
        errcode = code,
        message = msg,
        hint    = hint;
    end;
  end if;
end;
$body$;

drop function if exists interval_months(int, int) cascade;

create function interval_months(years in int default 0, months in int default 0)
  returns interval_months_t
  language plpgsql
as $body$
declare
begin
  call assert_interval_months_in_range(years*12::bigint + months::bigint);
  return make_interval(years => years, months => months);
end;
$body$;

drop function if exists interval_months(timestamptz, timestamptz) cascade;

create function interval_months(t_finish in timestamptz, t_start in timestamptz)
  returns interval_months_t
  language plpgsql
as $body$
declare
  finish_year   constant int     not null := extract(year  from t_finish);
  finish_month  constant int     not null := extract(month from t_finish);
  finish_AD_BC  constant text    not null := to_char(t_finish, 'BC');
  finish_is_BC  constant boolean not null :=
    case
      when finish_AD_BC = 'BC' then true
      when finish_AD_BC = 'AD' then false
    end;

  start_year   constant int not null := extract(year  from t_start);
  start_month  constant int not null := extract(month from t_start);
  start_AD_BC  constant text    not null := to_char(t_start, 'BC');
  start_is_BC  constant boolean not null :=
    case
      when start_AD_BC = 'BC' then true
      when start_AD_BC = 'AD' then false
    end;

  -- There is no "year zero". Therefore, when the two input moments straddle
  -- the AD/BC boundary, we must subtract 12 months to the computed months difference
  diff_as_months constant int not null :=
    (
      (finish_year*12 + finish_month)
      -
      (start_year*12  + start_month)
    )
    - case (finish_is_BC = start_is_BC)
        when true then 0
        else           12
      end;
begin
  call assert_interval_months_in_range(diff_as_months);
  return make_interval(months => diff_as_months);
end;
$body$;

drop function if exists interval_months(interval_months_t, double precision) cascade;

create function interval_months(i in interval_months_t, f in double precision)
  returns interval_months_t
  language plpgsql
as $body$
declare
  mm      constant double precision  not null := (interval_mm_dd_ss(i)).mm;
  mm_x_f  constant int               not null := round(mm*f);
  i_x_f   constant interval_months_t not null := interval_months(months=>mm_x_f);
begin
  return i_x_f;
end;
$body$;

----------------------------------------
-- interval_days

drop procedure if exists assert_interval_days_in_range(bigint);

create procedure assert_interval_days_in_range(days in bigint)
  language plpgsql
as $body$
declare
  -- Determined by empirical testing.
  -- Result is ts_max = '294276-01-01 00:00:00 UTC AD'.
  -- select '4713-01-01 00:00:00 UTC BC'::timestamptz + make_interval(days=>109203124);
  max_days constant bigint not null :=  109203124;

  -- "22015" is pre-defined and mapped to "interval_field_overflow".
  code     constant text   not null := '22015';
  hint     constant text   not null := 'Max interval_days_t exceeded';
begin
  if abs(days) > max_days then
    declare
      msg constant text := days::text||' abs(days) exceeded limit of '||max_days::text;
    begin
      raise exception using
        errcode = code,
        message = msg,
        hint    = hint;
    end;
  end if;
end;
$body$;

drop function if exists interval_days(int) cascade;

create function interval_days(days in int default 0)
  returns interval_days_t
  language plpgsql
as $body$
declare
begin
  call assert_interval_days_in_range(days);
  return make_interval(days => days);
end;
$body$;

drop function if exists interval_days(timestamptz, timestamptz) cascade;

create function interval_days(t_finish in timestamptz, t_start in timestamptz)
  returns interval_days_t
  language plpgsql
as $body$
declare
  d_finish constant date not null := t_finish::date;
  d_start  constant date not null := t_start::date;
  delta    constant int  not null := d_finish - d_start;
begin
  call assert_interval_days_in_range(delta);
  return make_interval(days => delta);
end;
$body$;

drop function if exists interval_days(interval_days_t, double precision) cascade;

create function interval_days(i in interval_days_t, f in double precision)
  returns interval_days_t
  language plpgsql
as $body$
declare
  dd      constant double precision not null := (interval_mm_dd_ss(i)).dd;
  dd_x_f  constant int              not null := round(dd*f);
  i_x_f   constant interval_days_t  not null := interval_days(days=>dd_x_f);
begin
  return i_x_f;
end;
$body$;

----------------------------------------
-- interval_seconds

drop procedure if exists assert_interval_seconds_in_range(bigint);

create procedure assert_interval_seconds_in_range(secs in bigint)
  language plpgsql
as $body$
declare
  /*
  -- 248551 years 4 mons 5 days
select
  date_trunc('year',
    justify_interval(
      interval_seconds(secs=>7730941132799)
    )
  );
  */
  -- Determined by empirical testing and backed up by reasoning.
  max_secs constant bigint not null :=   (2^31 - 1)*60*60 + 59*60 + 59;
  min_secs constant bigint not null := -((2^31    )*60*60 + 59*60 + 59);

  -- "22015" is pre-defined and mapped to "interval_field_overflow".
  code     constant text   not null := '22015';
  hint     constant text   not null := 'Use interval_days() or interval_months() instead.';
begin
  if secs > max_secs then
    declare
      msg constant text := secs::text||' seconds above upper limit of '||max_secs::text;
    begin
      raise exception using
        errcode = code,
        message = msg,
        hint    = hint;
    end;
  end if;
  if secs < min_secs then
    declare
      msg constant text := secs::text||' seconds below lower limit of '||min_secs::text;
    begin
      raise exception using
        errcode = code,
        message = msg,
        hint    = hint;
    end;
  end if;
end;
$body$;

drop function if exists interval_seconds(int, int, double precision) cascade;

create function interval_seconds(hours in int default 0, mins in int default 0, secs in double precision default 0.0)
  returns interval_seconds_t
  language plpgsql
as $body$
declare
  total_seconds bigint not null := hours*60*60 + mins*60 + trunc(secs)::bigint;
begin
  call assert_interval_seconds_in_range(total_seconds); 
  return make_interval(hours => hours, mins => mins, secs => secs)::interval_seconds_t;
end;
$body$;

drop function if exists interval_seconds(timestamptz, timestamptz) cascade;

create function interval_seconds(t_finish in timestamptz, t_start in timestamptz)
  returns interval_seconds_t
  language plpgsql
as $body$
declare
  s_finish constant double precision not null := extract(epoch from t_finish);
  s_start  constant double precision not null := extract(epoch from t_start);
  delta    constant double precision not null := s_finish - s_start;
begin
  call assert_interval_seconds_in_range(trunc(delta)::bigint);
  return make_interval(secs => delta);
end;
$body$;

drop function if exists interval_seconds(interval_seconds_t, double precision) cascade;

create function interval_seconds(i in interval_seconds_t, f in double precision)
  returns interval_seconds_t
  language plpgsql
as $body$
declare
  ss      constant double precision  not null := (interval_mm_dd_ss(i)).ss;
  ss_x_f  constant double precision  not null := ss*f;
  i_x_f   constant interval_seconds_t not null := interval_seconds(secs=>ss_x_f);
begin
  return i_x_f;
end;
$body$;

/*
select make_interval(years=>3, months=>99)*0.5378;
select (interval_months(years=>3, months=>99)*0.5378)::interval_months_t;
select interval_months(interval_months(years=>3, months=>99), 0.5378);

select interval_days(interval_days(days=>99), 7.5378);

select interval_seconds(interval_seconds(hours=>77, secs=>99), 0.54321);
*/;
