with
  c1 as (
    select utc_offset as "Offset"
    from canonical_real_country_no_dst
    union
    select std_offset as "Offset"
    from canonical_real_country_with_dst
    union
    select dst_offset as "Offset"
    from canonical_real_country_with_dst),
  c2 as (
    select interval_mm_dd_ss("Offset") as x
    from c1)
select to_char((c2.x).ss/3600.0, '09.99') as "Offset"
from c2
order by (c2.x);
