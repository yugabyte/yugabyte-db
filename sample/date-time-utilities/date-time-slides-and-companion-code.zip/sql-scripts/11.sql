\x off
\t on

drop function if exists i_repn(interval) cascade;

-- Same code as is used in 08.sql
create function i_repn(i in interval)
  returns text
  language plpgsql
as $body$
declare
  repn constant interval_mm_dd_ss_t not null := interval_mm_dd_ss(i);
  mm constant text not null := (repn.mm)::text;
  dd constant text not null := (repn.dd)::text;
  ss constant text not null := (repn.ss)::text;
begin
  return '['||mm||', '||dd||', '||ss||']';
end;
$body$;

drop function if exists f() cascade;

create function f()
  returns table(z text)
  language plpgsql
as $body$
declare
  t1        constant timestamptz not null := '2021-01-01 12:00:00 UTC';
  t2        constant timestamptz not null := '2021-11-30 23:55:55 UTC';
  i_hybrid  constant text        not null := i_repn(t2 - t1);
  i_mm      constant text        not null := i_repn(interval_months (t2, t1));
  i_dd      constant text        not null := i_repn(interval_days   (t2, t1));
  i_ss      constant text        not null := i_repn(interval_seconds(t2, t1));
begin
  z := 'i_hybrid: '||i_hybrid;                  return next;
  z := 'i_mm:     '||i_mm;                      return next;
  z := 'i_dd:     '||i_dd;                      return next;
  z := 'i_ss:     '||i_ss;                      return next;
end;
$body$;

select z from f();


\t off
select (interval_months(months=>99)*1.5432)::text;
select (interval_months(months=>99)*1.5432)::interval_months_t;

with c as (
  select interval_months(months=>99) as i_mm999)
select
  i_repn(i_mm999)                                 as "pure input",
  i_repn(i_mm999*1.5432)                          as "crazy hybrid result",
  i_repn(interval_months(i=>i_mm999, f=>1.5432))  as "sensible pure result"
from c;
