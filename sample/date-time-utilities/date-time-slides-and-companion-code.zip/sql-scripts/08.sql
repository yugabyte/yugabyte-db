drop function if exists i_repn(interval) cascade;

create function i_repn(i in interval)
  returns text
  language plpgsql
as $body$
declare
  repn constant interval_mm_dd_ss_t not null := interval_mm_dd_ss(i);
  mm constant text not null := (repn.mm)::text;
  dd constant text not null := (repn.dd)::text;
  ss constant text not null := (repn.ss)::text;
begin
  return '['||mm||', '||dd||', '||ss||']';
end;
$body$;

\x on
\t on

/*
select
  i_repn(make_interval(months => 1))            as "1 month",
  i_repn(make_interval(days   => 30))           as "30 days",
  i_repn(make_interval(secs   => 30*24*60*60))  as "30*24 hours",
  i_repn('7.123456 months'::interval)           as "'7.123456 months'::interval";
*/;

drop function if exists f(text) cascade;

create function f(timezone in text)
  returns table(z text)
  language plpgsql
as $body$
declare
  t constant timestamptz not null := at_timezone(timezone, '2021-03-10 12:00'::timestamp);
  i1 constant interval not null := make_interval(months=>1);
  i2 constant interval not null := make_interval(days=>30);
  i3 constant interval not null := make_interval(secs=>2592000);
begin
  z := 'i1:                   '||i1::text;                          return next;
  z := 'i2:                   '||i2::text;                          return next;
  z := 'i3:                   '||i3::text;                          return next;
  z := '';                                                          return next;

  z := 'i1_repn:              '||i_repn(i1);                        return next;
  z := 'i2_repn:              '||i_repn(i2);                        return next;
  z := 'i3_repn:              '||i_repn(i3);                        return next;
  z := '';                                                          return next;

  z := 'i2 = i1:              '||(i2 = i1)::text;                   return next;
  z := 'i3 = i1:              '||(i3 = i1)::text;                   return next;
  z := '';                                                          return next;

  z := 'i2 == i1:             '||(i2 == i1)::text;                  return next;
  z := 'i3 == i1:             '||(i3 == i1)::text;                  return next;
  z := '';                                                          return next;

  z := 't:                    '||t::text;                           return next;
  z := 't + i1:               '||(t + i1)::text;                    return next;
  z := 't + i2:               '||(t + i2)::text;                    return next;
  z := 't + i3:               '||(t + i3)::text;                    return next;
  z := '';                                                          return next;

  z := '(t + i1) = (t + i2):  '||((t + i1) = (t + i2))::text;       return next;
  z := '(t + i1) = (t + i3):  '||((t + i1) = (t + i3))::text;       return next;
  z := '(t + i2) = (t + i3):  '||((t + i2) = (t + i3))::text;       return next;
end;
$body$;

\x off
\t on

call set_timezone('America/Los_Angeles');
select z from f('America/Los_Angeles');

select rpad('-', 80, '-');

call set_timezone('Asia/Kathmandu');
select z from f('Asia/Kathmandu');
