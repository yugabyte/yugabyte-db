drop function if exists f() cascade;

create function f()
  returns table(z text)
  language plpgsql
as $body$
declare
  tz  constant text        not null := 'America/Los_Angeles';
  t1  constant timestamptz not null := at_timezone(tz, '2021-03-10 12:00'::timestamp);
  i1  constant interval    not null := '1 month'  ::interval;
  i2  constant interval    not null := '29 days'  ::interval;
  i3  constant interval    not null := '23:59:59' ::interval;

  t2  constant timestamptz not null := ((t1 + i1) + i2) + i3;
  t3  constant timestamptz not null := ((t1 + i3) + i2) + i1;

  b   constant boolean     not null := t2 = t3;
begin
  z := 't1:                                                 '||t1::text;      return next;
  z := '((t1 + i1) + i2) + i3:                              '||t2::text;      return next;
  z := '((t1 + i3) + i2) + i1:                              '||t3::text;      return next;
  z:= '';                                                                     return next;
  z := '(((t1 + i1) + i2) + i3) = (((t1 + i3) + i2) + i1):  '||b::text;       return next;
end;
$body$;

\x off
\t on
call set_timezone('America/Los_Angeles');
select z from f();
