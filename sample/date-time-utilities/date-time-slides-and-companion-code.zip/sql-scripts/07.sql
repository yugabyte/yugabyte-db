deallocate all;
prepare stmt as
select date_part('epoch', '2021-06-15 12:00:00 UTC'::timestamptz) as epoch;

call set_timezone('America/Los_Angeles');
execute stmt;

call set_timezone('Asia/Kathmandu');
execute stmt;
