drop function if exists reigning_timezone_offset() cascade;

create function reigning_timezone_offset()
  returns interval
  language plpgsql
as $body$
declare
  t  constant timestamptz not null := transaction_timestamp();
  h  constant int         not null := date_part('timezone_hour', t)::int;
  m  constant int         not null := date_part('timezone_minute', t)::int;
  i  constant interval    not null := make_interval(hours=>h, mins=>m);
begin
  return i;
end;
$body$;

drop table if exists events cascade;
create table events(
  k               serial       primary key,
  created_ts      timestamptz  not null default transaction_timestamp(),
  created_tz      interval     not null default reigning_timezone_offset(),
  created_tzname  text         not null default current_setting('TimeZone'),
  what            text         not null);

call set_timezone('America/Los_Angeles');
insert into events(What) values('Arrived Los_Angeles');

call set_timezone('Europe/London');
insert into events(What) values('Arrived London');

call set_timezone('Asia/Kathmandu');
insert into events(What) values('Arrived Kathmandu');

call set_timezone('UTC');
select created_ts::text, created_tz::text, created_tzname, what
from events
order by k;

with c as (
  select k, at_timezone(created_tz, created_ts) as ts, what
  from events)
select
  to_char(ts::date, 'Day dd-Mon-yyyy'        )  as "Local Date",
  to_char(ts::time,                 'hh24:mi')  as "Local Time",
  what
from c
order by k;

