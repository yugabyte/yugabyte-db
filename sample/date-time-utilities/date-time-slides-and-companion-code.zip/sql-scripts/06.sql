-- This is done when the app is installed.
drop table if exists meetings cascade;
create table meetings(k int primary key, t timestamptz);

deallocate all;

prepare cr_mtg(int, text, int, text) as
insert into meetings (k, t) values
  ($1, $2::timestamptz),
  ($3, $4::timestamptz);

prepare qry_mtg as
select
  k                                                                  as "Mtg",
  to_char(t, 'Dy hh24-mi on dd-Mon-yyyy TZ ["with offset" TZH:TZM]') as "When"
from meetings
order by k;

-- Rickie has the timezone 'Europe/Amsterdam' set in her calendar preferences.
-- Notice that Daylight Savings Time starts, in LA,
-- on Sunday 14-Mar-2021
set timezone = 'America/Los_Angeles';
execute cr_mtg(
  1, '2021-03-09 08:00',
  2, '2021-03-16 08:00');

execute qry_mtg;

-- Vincent has the timezone 'Europe/Amsterdam' set in his calendar preferences.
-- Notice that Daylight Savings Time starts, in Amsterdam,
-- on Sunday 28-Mar-2021

set timezone = 'Europe/Amsterdam';
execute qry_mtg;
