drop function if exists f() cascade;

create function f()
  returns table(z text)
  language plpgsql
as $body$
declare
  tz    constant text        not null := 'America/Los_Angeles';
  t1    constant timestamptz not null := at_timezone(tz, '2021-03-10 12:00'::timestamp);
  t2    constant timestamptz not null := at_timezone(tz, '2021-04-09 13:30'::timestamp);
  diff  constant interval    not null := t2 - t1;
  t3    constant timestamptz not null := t1 + diff;
  b     constant boolean     not null := t3 = t2;
begin
  z := 't1:                     '||t1::text;              return next;
  z := 't2:                     '||t2::text;              return next;
  z := 't2 - t1:                '||i_repn(diff);          return next;
  z := 't1 + (t2 - t1):         '||t3::text;              return next;
  z := '';                                                return next;
  z := '(t1 + (t2 - t1)) = t2:  '||b::text;               return next;
end;
$body$;

\x off
\t on
call set_timezone('America/Los_Angeles');
select z from f();
