deallocate all;
prepare stmt as
with c as (
  select '2021-01-01 01:00:00'::timestamp as t)
select
  at_timezone('America/Los_Angeles',    t)::text as t1,
  at_timezone(make_interval(hours=>-8), t)::text as t2
from c;

\x on
\t on

call set_timezone('America/New_York');
execute stmt;

call set_timezone(make_interval(hours=>-5));
execute stmt;

drop function if exists f() cascade;
create function f()
  returns table(z text)
  language plpgsql
as $body$
declare
  msg  text;
  hint text;
begin
  begin
    call set_timezone('Etc/GMT-99');
  exception
    when invalid_parameter_value then
      get stacked diagnostics
        msg  = message_text,
        hint = pg_exception_hint;
      z := msg;  return next;
      z := hint; return next;
  end;

  z := '';  return next;

  declare
    ts   constant timestamp not null := '2021-01-01 01:00:00';
    tstz          timestamp;
  begin
    tstz := at_timezone('Etc/GMT-99', ts);
  exception
    when invalid_parameter_value then
      get stacked diagnostics
        msg  = message_text,
        hint = pg_exception_hint;
      z := msg;  return next;
      z := hint; return next;
  end;
end;
$body$;

\x off
\t on
select z from f();
