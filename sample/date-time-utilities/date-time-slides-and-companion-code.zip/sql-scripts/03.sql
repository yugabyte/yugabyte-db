set timezone = 'UTC';

\t on
\x on

-- Using "at time zone" / timezone()
with c as (
  select '2021-01-01 01:00:00'::timestamp as t)
select
  timezone('America/Los_Angeles',    t)::text as t1,
  timezone(make_interval(hours=>-8), t)::text as t2,
  timezone('Etc/GMT-8',              t)::text as t3,
  timezone('Foo-8',                  t)::text as t4
from c;

-- Within the text of a timestamptz literal
with c as (
  select '2021-01-01 01:00:00'::text as t)
select
  (t||' America/Los_Angeles')::timestamptz as t1,
  (t||' Foo-8'              )::timestamptz as t2
from c;
