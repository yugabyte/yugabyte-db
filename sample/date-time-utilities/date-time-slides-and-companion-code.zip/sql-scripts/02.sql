select name, utc_offset
from pg_timezone_names
where name in ('Etc/GMT-8', 'Etc/GMT-99');

set timezone = 'Etc/GMT-99';
select ('2021-06-15 12:00:00 UTC'::timestamptz)::text;

select
  name,
  lpad(std_offset::text, 9) as std_offset,
  lpad(dst_offset::text, 9) as std_offset  
from extended_timezone_names
where name in ('Etc/GMT-8', 'America/Los_Angeles')
order by name;
