-- You must run this from "0.sql" on the parent directory.
-- The general mechanisms of "ysqlsh" and "psql" lacks a useful notion
-- that corresponds to "\ir" for "\o".

\ir cr-approved-timezone-names.sql
\ir distinct-offsets-from-approved-timezone-names.sql
\ir cr-assert-approved-timezone-name.sql
\ir cr-assert-acceptable-timezone-interval.sql
\ir cr-set-timezone.sql
\ir cr-at-timezone.sql
\ir do-set-timezone-tests.sql
\ir do-at-timezone-tests.sql
