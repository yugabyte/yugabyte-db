-- Interval parameterization as [yy, mm, dd, hh, mi, ss]

drop type if exists interval_parameterization_t cascade;
create type interval_parameterization_t as(
  yy numeric, mm numeric, dd numeric, hh numeric, mi numeric, ss numeric);

drop function if exists interval_parameterization(numeric, numeric, numeric, numeric, numeric, numeric);
create function interval_parameterization(
  yy in numeric default 0,
  mm in numeric default 0,
  dd in numeric default 0,
  hh in numeric default 0,
  mi in numeric default 0,
  ss in numeric default 0)
  returns interval_parameterization_t
  language plpgsql
as $body$
declare
  ok constant boolean :=
    (yy is not null) and
    (mm is not null) and
    (dd is not null) and
    (hh is not null) and
    (mi is not null) and
    (ss is not null);
  p interval_parameterization_t not null :=
   (yy, mm, dd, hh, mi, ss)::interval_parameterization_t;
begin
  assert ok, 'No argument, when provided, may be null';
  return p;
end;
$body$;
--------------------------------------------------------------------------------
-- Create an actual interval value from [yy, mm, dd, hh, mi, ss].

drop function if exists interval_value(interval_parameterization_t) cascade;
create function interval_value(p in interval_parameterization_t)
  returns interval
  language plpgsql
as $body$
declare
  yy constant interval not null := p.yy::text ||' years';
  mm constant interval not null := p.mm::text ||' months';
  dd constant interval not null := p.dd::text ||' days';
  hh constant interval not null := p.hh::text ||' hours';
  mi constant interval not null := p.mi::text ||' minutes';
  ss constant interval not null := p.ss::text ||' seconds';
begin  
  return yy + mm + dd + hh + mi + ss;
end;
$body$;

--------------------------------------------------------------------------------
-- Extract [yy, mm, dd, hh, mi, ss] from an actual interval value.

drop function if exists parameterization(interval) cascade;
create function parameterization(i in interval)
  returns interval_parameterization_t
  language plpgsql
as $body$
declare
  yy numeric          not null := extract(years   from i);
  mm numeric          not null := extract(months  from i);
  dd numeric          not null := extract(days    from i);
  hh numeric          not null := extract(hours   from i);
  mi numeric          not null := extract(minutes from i);
  ss numeric(1000, 6) not null := extract(seconds from i);
begin
  return (yy, mm, dd, hh, mi, ss)::interval_parameterization_t;
end;
$body$;

--------------------------------------------------------------------------------
-- Model an interval as a UDT [mm, dd, ss] tuple.

drop type if exists interval_mm_dd_ss_t cascade;
create type interval_mm_dd_ss_t as(
  mm int, dd int, ss numeric(1000,6));

-- Create an interval_mm_dd_ss_t value from an actual interval value
drop function if exists interval_mm_dd_ss(interval) cascade;

create function interval_mm_dd_ss(i in interval)
  returns interval_mm_dd_ss_t
  language plpgsql
as $body$
begin
  if i is null then
    return null;
  else
    declare
      mm constant int not null := (extract(years from i))*12 +
                                  extract(months from i);

      dd constant int not null := extract(days from i);

      ss constant numeric(1000,6) not null := (extract(hours from i))*60*60 +
                                  extract(minutes from i)*60 +
                                  extract(seconds from i);
    begin
      return (mm, dd, ss);
    end;
  end if;
end;
$body$;

--------------------------------------------------------------------------------
-- Create an actual interval value from [mm, dd, ss].

drop function if exists interval_value(interval_mm_dd_ss_t) cascade;
create function interval_value(i in interval_mm_dd_ss_t)
  returns interval
  language plpgsql
as $body$
begin  
  return make_interval(months=>i.mm, days=>i.dd, secs=>i.ss);
end;
$body$;

--------------------------------------------------------------------------------
-- Extract [yy, mm, dd, hh, mi, ss] parameterization from a [mm, dd, ss] tuple.

drop function if exists parameterization(interval_mm_dd_ss_t) cascade;
create function parameterization(i in interval_mm_dd_ss_t)
  returns interval_parameterization_t
  language plpgsql
as $body$
declare
  yy constant int              := trunc(i.mm/12);
  mm constant int              := i.mm - yy*12;
  dd constant int              := i.dd;
  hh constant int              := trunc(i.ss/(60.0*60.0));
  mi constant int              := trunc((i.ss - hh*60.0*60)/60.0);
  ss constant numeric(1000, 6) := i.ss - (hh*60.0*60.0 + mi*60.0);
begin
  return (
    yy::numeric,
    mm::numeric,
    dd::numeric,
    hh::numeric,
    mi::numeric,
    ss)::interval_parameterization_t;
end;
$body$;

----------------------------------------------------------------------------------------------------

drop function if exists strict_equals(interval, interval) cascade;

create function strict_equals(i1 in interval, i2 in interval)
  returns boolean
  language plpgsql
as $body$
declare
  mm_dd_ss_1 constant interval_mm_dd_ss_t := interval_mm_dd_ss(i1);
  mm_dd_ss_2 constant interval_mm_dd_ss_t := interval_mm_dd_ss(i2);
begin
  return mm_dd_ss_1 = mm_dd_ss_2;
end;
$body$;

create operator == (
    leftarg   = interval,
    rightarg  = interval,
    procedure = strict_equals
);

----------------------------------------------------------------------------------------------------
-- Notice that there is no native plain timestamp eqivalent of to_timestamp().
drop function if exists to_timestamp_without_tz(double precision);

create function to_timestamp_without_tz(ss_from_epoch in double precision)
  returns /* plain */ timestamp
  language plpgsql
as $body$
declare
  current_tz text not null := '';
begin
  -- Save present setting.
  -- OR select current_setting('TimeZone');
  show timezone into current_tz;
  assert length(current_tz) > 0, 'undefined time zone';
  set timezone = 'UTC';
  declare
    t_tz constant timestamptz := to_timestamp(ss_from_epoch);
    t    constant timestamp   := t_tz at time zone 'UTC';
  begin
    -- Restore the saved time zone setting.
    execute 'set timezone = '''||current_tz||'''';
    return t;
  end;
end;
$body$;

----------------------------------------------------------------------------------------------------
-- Notice that there is no native to_time().

drop function if exists to_time(numeric) cascade;

create function to_time(ss in numeric)
  returns time
  language plpgsql
as $body$
declare
  -- Notice the ss can be bigger than ss_per_day.
  ss_per_day        constant numeric not null := 24.0*60.0*60.0;
  ss_from_midnight  constant numeric not null := mod(ss, ss_per_day);
  t                 constant time    not null :=
                      make_interval(
                        secs=>ss_from_midnight::double precision)::time;
begin
  return t;
end;
$body$;
