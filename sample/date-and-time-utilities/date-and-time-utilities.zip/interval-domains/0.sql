\ir cr-code.sql
\ir do-tests.sql
