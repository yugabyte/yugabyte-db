-- Drop the temporary objects used to populate the "tz_database_time_zones_extended" table.
drop table    if exists tz_database_time_zones_stage cascade;
drop view     if exists tz_database_time_zones_view cascade;
drop view     if exists tz_database_time_zones_extended_raw cascade;
drop table    if exists bad_names cascade;
drop function if exists tz_database_time_zones_extended_good() cascade;
drop function if exists extended_timezone_names_columns() cascade;
drop function if exists timezones_md_table() cascade;
